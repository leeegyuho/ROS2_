// generated from rosidl_generator_c/resource/idl.h.em
// with input from ros_study_msgs:srv/MySrv.idl
// generated code does not contain a copyright notice

#ifndef ROS_STUDY_MSGS__SRV__MY_SRV_H_
#define ROS_STUDY_MSGS__SRV__MY_SRV_H_

#include "ros_study_msgs/srv/detail/my_srv__struct.h"
#include "ros_study_msgs/srv/detail/my_srv__functions.h"
#include "ros_study_msgs/srv/detail/my_srv__type_support.h"

#endif  // ROS_STUDY_MSGS__SRV__MY_SRV_H_
