// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROS_STUDY_MSGS__SRV__MY_SRV_HPP_
#define ROS_STUDY_MSGS__SRV__MY_SRV_HPP_

#include "ros_study_msgs/srv/detail/my_srv__struct.hpp"
#include "ros_study_msgs/srv/detail/my_srv__builder.hpp"
#include "ros_study_msgs/srv/detail/my_srv__traits.hpp"
#include "ros_study_msgs/srv/detail/my_srv__type_support.hpp"

#endif  // ROS_STUDY_MSGS__SRV__MY_SRV_HPP_
