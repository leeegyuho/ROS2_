// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROS_STUDY_MSGS__MSG__MY_MSG_HPP_
#define ROS_STUDY_MSGS__MSG__MY_MSG_HPP_

#include "ros_study_msgs/msg/detail/my_msg__struct.hpp"
#include "ros_study_msgs/msg/detail/my_msg__builder.hpp"
#include "ros_study_msgs/msg/detail/my_msg__traits.hpp"
#include "ros_study_msgs/msg/detail/my_msg__type_support.hpp"

#endif  // ROS_STUDY_MSGS__MSG__MY_MSG_HPP_
