// generated from rosidl_generator_c/resource/idl.h.em
// with input from ros_study_msgs:msg/ArithmeticArgument.idl
// generated code does not contain a copyright notice

#ifndef ROS_STUDY_MSGS__MSG__ARITHMETIC_ARGUMENT_H_
#define ROS_STUDY_MSGS__MSG__ARITHMETIC_ARGUMENT_H_

#include "ros_study_msgs/msg/detail/arithmetic_argument__struct.h"
#include "ros_study_msgs/msg/detail/arithmetic_argument__functions.h"
#include "ros_study_msgs/msg/detail/arithmetic_argument__type_support.h"

#endif  // ROS_STUDY_MSGS__MSG__ARITHMETIC_ARGUMENT_H_
