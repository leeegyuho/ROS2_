// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROS_STUDY_MSGS__ACTION__MY_ACTION_HPP_
#define ROS_STUDY_MSGS__ACTION__MY_ACTION_HPP_

#include "ros_study_msgs/action/detail/my_action__struct.hpp"
#include "ros_study_msgs/action/detail/my_action__builder.hpp"
#include "ros_study_msgs/action/detail/my_action__traits.hpp"
#include "ros_study_msgs/action/detail/my_action__type_support.hpp"

#endif  // ROS_STUDY_MSGS__ACTION__MY_ACTION_HPP_
