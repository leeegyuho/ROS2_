// generated from rosidl_generator_c/resource/idl.h.em
// with input from ros_study_msgs:action/ArithmeticChecker.idl
// generated code does not contain a copyright notice

#ifndef ROS_STUDY_MSGS__ACTION__ARITHMETIC_CHECKER_H_
#define ROS_STUDY_MSGS__ACTION__ARITHMETIC_CHECKER_H_

#include "ros_study_msgs/action/detail/arithmetic_checker__struct.h"
#include "ros_study_msgs/action/detail/arithmetic_checker__functions.h"
#include "ros_study_msgs/action/detail/arithmetic_checker__type_support.h"

#endif  // ROS_STUDY_MSGS__ACTION__ARITHMETIC_CHECKER_H_
