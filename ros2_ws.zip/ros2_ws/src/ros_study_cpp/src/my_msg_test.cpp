#include "rclcpp/rclcpp.hpp" // 표준 ROS 2 C++ 클라이언트 라이브러리 헤더
#include "ros_study_msgs/msg/my_msg.hpp" // 사용자 정의 메시지 MyMsg의 헤더


class MyMsgPublisher : public rclcpp::Node // rclcpp::Node를 상속받는 MyMsgPublisher 클래스 정의 (이 클래스가 ROS 2 노드가 됨)
{
public:
    MyMsgPublisher() // 클래스의 생성자
    : Node("my_msg_test"), count_(0.0) // 부모 Node 클래스를 "my_msg_test" 이름으로 초기화하고, count_를 0.0으로 설정
    {
        // publisher_ = this->create_publisher<ros_study_msgs::msg::MyMsg>("MyMsg", 10);
        // 퍼블리셔를 생성합니다:
        // - <ros_study_msgs::msg::MyMsg>는 발행할 메시지 타입입니다.
        // - "MyMsg"는 토픽의 이름입니다.
        // - 10은 QoS 깊이(history 정책은 KEEP_LAST, 깊이 10)입니다.
        // (주석 처리된 'this'와 가상 함수에 대한 내용은 ROS 2 기능 자체보다는 C++ 개발자 노트입니다.)

        publisher_ = this->create_publisher<ros_study_msgs::msg::MyMsg>("MyMsg", 10); // 실제 퍼블리셔 생성 코드
        
        // timer_ = this->create_wall_timer(
        //     std::chrono::milliseconds(500),
        //     std::bind(&MyMsgPublisher::timer_callback, this));
        // 주기적인 실행을 위한 벽 타이머를 생성합니다:
        // - std::chrono::milliseconds(500): 타이머 주기 (500밀리초 = 0.5초)입니다.
        // - std::bind(&MyMsgPublisher::timer_callback, this): 타이머 만료 시 이 객체의 timer_callback 멤버 함수를 호출하도록 바인딩합니다.
        // (주석 처리된 멤버 함수 포인터에 대한 내용은 개발자 노트입니다.)
        timer_ = this->create_wall_timer(
            std::chrono::milliseconds(500), // 500ms (0.5초) 타이머 주기
            std::bind(&MyMsgPublisher::timer_callback, this)); // timer_callback 메서드를 타이머에 바인딩
    }

private:
    rclcpp::Publisher<ros_study_msgs::msg::MyMsg>::SharedPtr publisher_; // 퍼블리셔 객체에 대한 스마트 포인터
    rclcpp::TimerBase::SharedPtr timer_; // 타이머 객체에 대한 스마트 포인터
    float count_; // 카운트 값을 저장하는 멤버 변수 (C++에서는 float 타입)
    
    void timer_callback() // 타이머에 의해 주기적으로 호출되는 함수
    {
        auto message = ros_study_msgs::msg::MyMsg(); // 사용자 정의 메시지 타입 MyMsg의 인스턴스를 생성
        // 'auto'는 C++11의 기능으로, 컴파일러가 타입을 추론하게 합니다. 여기서는 ros_study_msgs::msg::MyMsg 타입입니다.
        message.num = count_; // 메시지의 'num' 필드에 현재 count_ 값을 할당
        publisher_->publish(message); // 퍼블리셔 포인터를 사용하여 메시지를 발행
        RCLCPP_INFO(this->get_logger(), "Publishing: %f", count_); // 콘솔에 정보 메시지를 로깅
         // RCLCPP_INFO는 Python의 get_logger().info()와 동일하며, printf와 같은 서식 지정자를 사용합니다.
        count_ += 1.0; // 다음 메시지를 위해 카운트 값을 1 증가
    }
};

int main(int argc, char * argv[]) // 프로그램 실행이 시작되는 메인 함수
{
    rclcpp::init(argc, argv); // ROS 2 C++ 클라이언트 라이브러리를 초기화
    rclcpp::spin(std::make_shared<MyMsgPublisher>()); // MyMsgPublisher의 인스턴스를 스마트 포인터로 생성하고 노드 스핀을 시작
    // 'spin'은 노드를 계속 활성 상태로 유지하며 콜백(예: timer_callback)을 처리하도록 합니다. 수동으로 종료될 때까지(예: Ctrl+C) 작동합니다.
    rclcpp::shutdown(); // ROS 2 C++ 클라이언트 라이브러리를 종료
    return 0; // 성공적인 실행을 나타냄
}