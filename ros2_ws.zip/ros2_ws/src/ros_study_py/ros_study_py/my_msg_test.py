import rclpy  #클라이언트 라이브러리를 임포트 하고 통신을 주고받는데 핵심 기능
from rclpy.node import Node #ROS2 노드의 기본이 되는 Node 클래스를 임포트 
from rclpy.qos import QoSProfile #QoS(Quality of Service)설정을 위해 필요한 클래스 
from ros_study_msgs.msg import MyMsg #패키지 안에 정의된 MyMsg라는 메시지 타입을 임포트하여 데이터를 주고 받음


class my_msg_test(Node):  # rclpy.node.Node를 상속받으므로 ROS2노드의 기능을 가짐

    def __init__(self):#생성자 
        super().__init__('my_msg_test') # 부모 클래스인 Node의 생성자를 호출하여 현재 노드의 이름을 
        #my_msg_test'로 설정
        qos_profile = QoSProfile(depth=10) # QoS 프로파일을 설정. 퍼블리셔가 발행한 메시지를 최대 
        #10개까지 버퍼링(큐에 저장)할 수 있다는 의미
        # QoS profile 은 ROS2 통신 시 메시지 전송의 품질과 특성을 설정하는 규칙들의 모임
        self.publisher_ = self.create_publisher(MyMsg, 'MyMsg', qos_profile) #이 노드의 퍼블리셔를 생성
        #MyMsg : 발행할 메시지의 타입
        #'MyMsg' : 메시지가 발행될 토픽의 이름 
        #qos_profile : 위에서 정의한 QoS설정을 적용
        timer_period = 0.5  # seconds  # 타이머의 주기를 0.5초로 설정
        self.timer = self.create_timer(timer_period, self.timer_callback)
        #timeer_callback 함수 호출
        self.i = 0.0

    def timer_callback(self):
        msg = MyMsg() #MyMsg타입의 새 메시지 객체를 생성
        msg.num = self.i#생성된 메시지 객체의 num 필드에 현재 self.i 값을 할당합니다.
        #(MyMsg 메시지 정의에 num이라는 필드가 있다고 가정합니다.)
        self.publisher_.publish(msg)#준비된 메시지(msg)를 MyMsg 토픽으로 발행
        self.get_logger().info(str(self.i)) 
        # ROS 2 로깅 시스템을 사용하여 현재 발행하는 self.i 값을 터미널에 정보 메시지로 출력
        self.i += 1#메시지의 값을 1 증가


def main(args=None):
    rclpy.init(args=args)
    # ROS 2 시스템과 통신을 시작하기 위해 rclpy 라이브러리를 초기화합니다. ROS 2 애플리케이션의 시작점

    my_msg_test_publisher = my_msg_test()
    #위에서 정의한 my_msg_test 노드 클래스의 인스턴스를 생성

    rclpy.spin(my_msg_test_publisher)
    #이 함수는 노드가 콜백(예: 타이머 콜백, 서브스크라이버 콜백)을 계속 처리하도록 합니다. 
    # 즉, 노드가 종료될 때까지 무한 루프를 돌면서 메시지를 발행하거나 받을 준비를 합니다.
    #  Ctrl+C와 같은 시그널을 받으면 spin 함수가 종료됩니다.

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    my_msg_test_publisher.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()