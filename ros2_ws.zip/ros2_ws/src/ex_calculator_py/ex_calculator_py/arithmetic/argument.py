import random

from ros_study_msgs.msg import ArithmeticArgument
from rcl_interfaces.msg import SetParametersResult
import rclpy
from rclpy.node import Node
from rclpy.parameter import Parameter
from rclpy.qos import QoSDurabilityPolicy
from rclpy.qos import QoSHistoryPolicy
from rclpy.qos import QoSProfile
from rclpy.qos import QoSReliabilityPolicy
from rclpy.logging import LoggingSeverity

class Argument(Node):

    def __init__(self):
        super().__init__('argument')
        self.get_logger().set_level(LoggingSeverity.INFO)
        self.get_logger().info('Argument init set start')

        self.declare_parameter('qos_depth', 10)
        qos_depth = self.get_parameter('qos_depth').value #10이 들어간다
        self.get_logger().info(f'qos_depth set {qos_depth}')#qos_depth에 뭐가 들어갔는지 로그로 확인

        self.declare_parameter('min_random_num', 0)
        self.min_random_num = self.get_parameter('min_random_num').value
        self.get_logger().info(f'min_random_num set {self.min_random_num}')

        self.declare_parameter('max_random_num', 9)
        self.max_random_num = self.get_parameter('max_random_num').value
        self.get_logger().info(f'max_random_num set {self.max_random_num}')

        self.add_on_set_parameters_callback(self.update_parameter)
        self.get_logger().info(f'add_on_set_parameters_callback on')

        QOS_RKL10V = QoSProfile(
            reliability=QoSReliabilityPolicy.RELIABLE,
            history=QoSHistoryPolicy.KEEP_LAST,
            depth=qos_depth,
            durability=QoSDurabilityPolicy.VOLATILE)
        self.get_logger().info('QOS_RKL10V get QoSProfile')

        self.arithmetic_argument_publisher = self.create_publisher(
            ArithmeticArgument,
            'arithmetic_argument',
            QOS_RKL10V)
        self.timer = self.create_timer(1.0, self.publish_random_arithmetic_arguments)
        self.get_logger().info('publish topic : arithmetic_argument_publisher')
        self.get_logger().info('end init')

    def publish_random_arithmetic_arguments(self):
        self.get_logger().info('start publish_random_arithmetic_arguments')
        msg = ArithmeticArgument()
        msg.stamp = self.get_clock().now().to_msg()
        msg.argument_a = float(random.randint(self.min_random_num, self.max_random_num))
        msg.argument_b = float(random.randint(self.min_random_num, self.max_random_num))
        self.arithmetic_argument_publisher.publish(msg)
        self.get_logger().info(f'Published argument a: {msg.argument_a}')
        self.get_logger().info(f'Published argument b: {msg.argument_b}')

    def update_parameter(self, params):
        self.get_logger().info('start update_parameter')
        for param in params:
            if param.name == 'min_random_num' and param.type_ == Parameter.Type.INTEGER:
                self.min_random_num = param.value
                self.get_logger().info(f'self.min_random_num = {self.min_random_num}')
            elif param.name == 'max_random_num' and param.type_ == Parameter.Type.INTEGER:
                self.max_random_num = param.value
                self.get_logger().info(f'self.max_random_num = {self.max_random_num}')
        return SetParametersResult(successful=True)
    #여기에 로그 남기면 안됨 return에서 함수 끝

def main(args=None):
    rclpy.init(args=args)
    try:
        argument = Argument()
        try:
            rclpy.spin(argument) 
            # 모든 콜백 함수(예: 타이머 콜백, 구독자 콜백, 서비스 콜백 등)를 처리하고 메시지를 주고받도록 하는 핵심 함수
        except KeyboardInterrupt: #예외처리
            #사용자가 Ctrl+C를 눌러 프로그램을 종료하려고 할 때 발생하는 KeyboardInterrupt 예외를 잡아냅니다.
            argument.get_logger().info('Keyboard Interrupt (SIGINT)')
            #Ctrl+C 를 눌ㄹ 종료하면 표시됨
        finally:#블록에서 예외가 발생하든 안 하든 항상 실행됩니다
            argument.destroy_node()
    finally:
        rclpy.shutdown()

if __name__ == '__main__':
    main()

        

