from setuptools import find_packages, setup

package_name = 'hangman_game_py'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='hkit',
    maintainer_email='gyuho.dns03057@naver.com',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'letter_publisher = hangman_game_py.letter_publisher:main',
            'user_input = hangman_game_py.user_input:main',
            'word_service = hangman_game_py.word_service:main',
            'progress_action_client = hangman_game_py.progress_action_client:main',
            'progress_action_server = hangman_game_py.progress_action_server:main',
        ],
    },
)
