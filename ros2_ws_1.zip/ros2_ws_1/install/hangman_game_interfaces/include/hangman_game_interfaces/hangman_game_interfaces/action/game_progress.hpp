// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef HANGMAN_GAME_INTERFACES__ACTION__GAME_PROGRESS_HPP_
#define HANGMAN_GAME_INTERFACES__ACTION__GAME_PROGRESS_HPP_

#include "hangman_game_interfaces/action/detail/game_progress__struct.hpp"
#include "hangman_game_interfaces/action/detail/game_progress__builder.hpp"
#include "hangman_game_interfaces/action/detail/game_progress__traits.hpp"
#include "hangman_game_interfaces/action/detail/game_progress__type_support.hpp"

#endif  // HANGMAN_GAME_INTERFACES__ACTION__GAME_PROGRESS_HPP_
