// generated from rosidl_generator_c/resource/idl.h.em
// with input from hangman_game_interfaces:msg/Progress.idl
// generated code does not contain a copyright notice

#ifndef HANGMAN_GAME_INTERFACES__MSG__PROGRESS_H_
#define HANGMAN_GAME_INTERFACES__MSG__PROGRESS_H_

#include "hangman_game_interfaces/msg/detail/progress__struct.h"
#include "hangman_game_interfaces/msg/detail/progress__functions.h"
#include "hangman_game_interfaces/msg/detail/progress__type_support.h"

#endif  // HANGMAN_GAME_INTERFACES__MSG__PROGRESS_H_
