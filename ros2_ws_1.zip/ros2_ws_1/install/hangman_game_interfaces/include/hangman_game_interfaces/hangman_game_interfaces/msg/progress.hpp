// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef HANGMAN_GAME_INTERFACES__MSG__PROGRESS_HPP_
#define HANGMAN_GAME_INTERFACES__MSG__PROGRESS_HPP_

#include "hangman_game_interfaces/msg/detail/progress__struct.hpp"
#include "hangman_game_interfaces/msg/detail/progress__builder.hpp"
#include "hangman_game_interfaces/msg/detail/progress__traits.hpp"
#include "hangman_game_interfaces/msg/detail/progress__type_support.hpp"

#endif  // HANGMAN_GAME_INTERFACES__MSG__PROGRESS_HPP_
