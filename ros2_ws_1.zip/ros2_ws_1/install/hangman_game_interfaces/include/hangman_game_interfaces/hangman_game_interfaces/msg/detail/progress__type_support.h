// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from hangman_game_interfaces:msg/Progress.idl
// generated code does not contain a copyright notice

#ifndef HANGMAN_GAME_INTERFACES__MSG__DETAIL__PROGRESS__TYPE_SUPPORT_H_
#define HANGMAN_GAME_INTERFACES__MSG__DETAIL__PROGRESS__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "hangman_game_interfaces/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_hangman_game_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  hangman_game_interfaces,
  msg,
  Progress
)();

#ifdef __cplusplus
}
#endif

#endif  // HANGMAN_GAME_INTERFACES__MSG__DETAIL__PROGRESS__TYPE_SUPPORT_H_
