from hangman_game_interfaces.action._game_progress import GameProgress  # noqa: F401
