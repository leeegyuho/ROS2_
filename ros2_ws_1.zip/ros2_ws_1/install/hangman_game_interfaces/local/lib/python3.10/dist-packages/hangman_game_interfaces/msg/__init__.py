from hangman_game_interfaces.msg._progress import Progress  # noqa: F401
